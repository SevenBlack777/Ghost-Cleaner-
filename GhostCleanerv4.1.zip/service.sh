#!/system/bin/sh
MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/config.conf"
PATH_LIST="$MODDIR/paths.list"
LOG_FILE="$MODDIR/run.log"
PROP_FILE="$MODDIR/module.prop"
STATS_FILE="$MODDIR/stats.total"
LAST_RUN_FILE="$MODDIR/last_run.date" # 🆕 记录最后一次定时清理的日期

# ===========================
# 🛠️ 功能函数
# ===========================

log_msg() {
    echo "[$(date '+%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

rotate_log() {
    if [ -f "$LOG_FILE" ] && [ $(wc -l < "$LOG_FILE") -gt 300 ]; then
        tail -n 100 "$LOG_FILE" > "$LOG_FILE.tmp" && mv -f "$LOG_FILE.tmp" "$LOG_FILE"
        chmod 666 "$LOG_FILE"
    fi
}

check_battery() {
    BAT=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)
    if [ -z "$BAT" ]; then echo 100; else echo "$BAT"; fi
}

update_stats() {
    local added_bytes=$1
    [ -z "$added_bytes" ] && return
    local current_total=0
    if [ -f "$STATS_FILE" ]; then current_total=$(cat "$STATS_FILE"); fi
    case "$current_total" in ''|*[!0-9]*) current_total=0 ;; esac
    local new_total=$((current_total + added_bytes))
    echo "$new_total" > "$STATS_FILE"
    chmod 666 "$STATS_FILE"
}

# 🆕 检查是否在允许的时间段内
# 返回 0 (true) 表示在时间内，返回 1 (false) 表示不在时间内
check_time_window() {
    local s_hour=$1
    local e_hour=$2
    local cur_hour=$(date +%H)
    cur_hour=$((10#$cur_hour)) 
    s_hour=$((10#$s_hour))
    e_hour=$((10#$e_hour))

    # 同一天 (例如 10点 -> 18点)
    if [ "$s_hour" -lt "$e_hour" ]; then
        if [ "$cur_hour" -ge "$s_hour" ] && [ "$cur_hour" -lt "$e_hour" ]; then return 0; else return 1; fi
    # 跨天 (例如 22点 -> 06点)
    else
        if [ "$cur_hour" -ge "$s_hour" ] || [ "$cur_hour" -lt "$e_hour" ]; then return 0; else return 1; fi
    fi
}

# ===========================
# 🚀 初始化阶段
# ===========================

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done

if [ ! -f "$STATS_FILE" ]; then echo "0" > "$STATS_FILE"; fi
if [ ! -f "$PATH_LIST" ]; then touch "$PATH_LIST"; fi

# 初始化配置
if [ ! -f "$CONFIG_FILE" ]; then
    echo 'ENABLED="false"' > "$CONFIG_FILE"
    echo 'INTERVAL="60"' >> "$CONFIG_FILE"
    echo 'MAX_JOBS="10"' >> "$CONFIG_FILE"
fi

# 统一权限
chmod 666 "$CONFIG_FILE" "$PATH_LIST" "$LOG_FILE" "$STATS_FILE" "$LAST_RUN_FILE" 2>/dev/null

log_msg "Ghost Cleaner 服务已启动"

# ===========================
# 🔄 核心服务循环
# ===========================
while true; do

  # --- 防篡改 ---
  if ! grep -q "^author=酷安柒黑$" "$PROP_FILE"; then
      sed -i 's/^author=.*/author=酷安柒黑/' "$PROP_FILE"
  fi

  if [ -f "$CONFIG_FILE" ]; then
    # 读取基础配置
    CUR_ENABLED=$(grep '^ENABLED=' "$CONFIG_FILE" | cut -d'"' -f2)
    CUR_INTERVAL=$(grep '^INTERVAL=' "$CONFIG_FILE" | cut -d'"' -f2)
    CUR_MAX_JOBS=$(grep '^MAX_JOBS=' "$CONFIG_FILE" | cut -d'"' -f2)
    
    # 读取定时配置
    CUR_SCHED_EN=$(grep '^SCHEDULE_ENABLED=' "$CONFIG_FILE" | cut -d'"' -f2)
    CUR_START=$(grep '^START_HOUR=' "$CONFIG_FILE" | cut -d'"' -f2)
    CUR_END=$(grep '^END_HOUR=' "$CONFIG_FILE" | cut -d'"' -f2)
    CUR_SCHED_ONCE=$(grep '^SCHEDULE_ONCE=' "$CONFIG_FILE" | cut -d'"' -f2)

    # 默认值修正
    [ -z "$CUR_INTERVAL" ] && CUR_INTERVAL=60
    [ "$CUR_INTERVAL" -lt 5 ] && CUR_INTERVAL=60
    [ -z "$CUR_START" ] && CUR_START=0
    [ -z "$CUR_END" ] && CUR_END=0
    case "$CUR_MAX_JOBS" in ''|*[!0-9]*) CUR_MAX_JOBS=10 ;; esac

    # ---------------------------
    # 🔋 功能: 低电量暂停
    # ---------------------------
    BAT_LEVEL=$(check_battery)
    if [ "$BAT_LEVEL" -lt 20 ]; then
        if [ "$CUR_ENABLED" == "true" ]; then
             log_msg "⚠️ 电量过低 ($BAT_LEVEL%)，暂停清理..."
        fi
        sleep 60
        continue 
    fi

    # ---------------------------
    # ⏰ 功能: 定时与运行逻辑判断
    # ---------------------------
    should_run=true
    
    # 1. 总开关检查
    if [ "$CUR_ENABLED" != "true" ]; then
        should_run=false
    fi

    # 2. 定时逻辑检查
    if [ "$should_run" == "true" ] && [ "$CUR_SCHED_EN" == "true" ]; then
        
        # A. 检查当前时间是否在窗口内
        if ! check_time_window "$CUR_START" "$CUR_END"; then
            should_run=false 
        else
            # B. 如果在窗口内，且开启了"每日一次"
            if [ "$CUR_SCHED_ONCE" == "true" ]; then
                TODAY=$(date +%Y%m%d)
                LAST_RUN=""
                if [ -f "$LAST_RUN_FILE" ]; then
                    LAST_RUN=$(cat "$LAST_RUN_FILE")
                fi
                
                if [ "$LAST_RUN" == "$TODAY" ]; then
                    should_run=false
                else
                    log_msg "⏰ 到达设定时间，开始今日任务..."
                fi
            fi
        fi
    fi

    # ---------------------------
    # 🧹 执行清理
    # ---------------------------
    if [ "$should_run" == "true" ] && [ -s "$PATH_LIST" ]; then
        
        job_count=0
        BATCH_TMP="$MODDIR/batch_size.tmp"
        echo "0" > "$BATCH_TMP"

        while IFS= read -r target_path || [ -n "$target_path" ]; do
            if [ -z "$target_path" ] || [ "${target_path:0:1}" = "#" ]; then continue; fi

            (
                if [ -e "$target_path" ]; then
                    size_bytes=$(du -sb "$target_path" 2>/dev/null | awk '{print $1}')
                    
                    rm -rf "$target_path" >/dev/null 2>&1
                    
                    if [ ! -e "$target_path" ]; then
                         log_msg "🚀 已清理: $target_path"
                         if [ -n "$size_bytes" ]; then
                            echo "$size_bytes" >> "$BATCH_TMP"
                         fi
                    fi
                fi
            ) &

            job_count=$((job_count + 1))
            if [ "$job_count" -ge "$CUR_MAX_JOBS" ]; then
                wait
                job_count=0
            fi

        done < "$PATH_LIST"
        wait
        
        # 汇总统计
        total_batch=0
        if [ -f "$BATCH_TMP" ]; then
            while read -r line; do
                case "$line" in ''|*[!0-9]*) continue ;; esac
                total_batch=$((total_batch + line))
            done < "$BATCH_TMP"
            rm -f "$BATCH_TMP"
        fi

        if [ "$total_batch" -gt 0 ]; then
            update_stats "$total_batch"
        fi

        # 🆕 标记今日已运行
        if [ "$CUR_SCHED_EN" == "true" ] && [ "$CUR_SCHED_ONCE" == "true" ]; then
            date +%Y%m%d > "$LAST_RUN_FILE"
            log_msg "✅ 今日定时任务已完成。"
        fi

    fi
    rotate_log
  else
    CUR_INTERVAL=60
  fi

  sleep "$CUR_INTERVAL"
done