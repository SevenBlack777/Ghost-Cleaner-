#!/system/bin/sh

# 1. 定义模块 ID (必须与 module.prop 中的 id 一致)
MODID="ghost_cleaner_ui"

# 2. 定义旧的安装路径 (手机里正在运行的路径)
LIVE_DIR="/data/adb/modules/$MODID"

ui_print "- 正在检查旧配置..."

# 3. 恢复规则列表 (paths.list)
if [ -f "$LIVE_DIR/paths.list" ]; then
    ui_print "- 发现旧规则列表，正在备份..."
    cp -f "$LIVE_DIR/paths.list" "$MODPATH/paths.list"
    ui_print "- 规则列表已恢复 ✅"
else
    ui_print "- 未发现旧规则，将使用默认空白列表"
fi

# 4. 恢复配置文件 (config.conf)
if [ -f "$LIVE_DIR/config.conf" ]; then
    ui_print "- 发现旧配置文件，正在备份..."
    cp -f "$LIVE_DIR/config.conf" "$MODPATH/config.conf"
    ui_print "- 配置已恢复 ✅"
fi

# 5. 设置权限 (非常重要！)
# 确保 WebUI 有权限读写这些文件 (666 = rw-rw-rw-)
ui_print "-正在设置文件权限..."

set_perm_recursive "$MODPATH" 0 0 0755 0644

# 给脚本执行权限
set_perm "$MODPATH/service.sh" 0 0 0755

# 给配置文件读写权限 (防止恢复后 WebUI 无法写入)
set_perm "$MODPATH/paths.list" 0 0 0666
set_perm "$MODPATH/config.conf" 0 0 0666

ui_print "- 安装完成！"